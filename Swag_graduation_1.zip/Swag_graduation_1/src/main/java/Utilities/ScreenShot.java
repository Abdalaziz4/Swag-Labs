package Utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenShot {
    public static void TakeScreenShot(WebDriver driver, String TestCaseName) {
        // Create directory if it doesn't exist
        File directory = new File("ScreenShots");
        if (!directory.exists()) {
            directory.mkdir();
        }

        // Get current timestamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        File screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String fileName = "ScreenShots/" + TestCaseName + "_" + timeStamp + ".png";

        try {
            FileUtils.copyFile(screenShotFile, new File(fileName));
        } catch (IOException e) {
            System.out.println("Failed to capture screenshot: " + e.getMessage());
        }
    }

    public static void TakeScreenShot(WebDriver driver, String TestCaseName, String browserName) {
        // Create directory if it doesn't exist
        File directory = new File("ScreenShots");
        if (!directory.exists()) {
            directory.mkdir();
        }

        // Get current timestamp
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        File screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        String fileName = "ScreenShots/" + TestCaseName + "_" + browserName + "_" + timeStamp + ".png";

        try {
            FileUtils.copyFile(screenShotFile, new File(fileName));
        } catch (IOException e) {
            System.out.println("Failed to capture screenshot: " + e.getMessage());
        }
    }
}