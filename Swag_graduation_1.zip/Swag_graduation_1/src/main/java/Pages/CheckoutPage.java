package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Utilities.ScreenShot;

public class CheckoutPage {
    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By zipCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By finishButton = By.id("finish");
    private final By cancelButton = By.id("cancel");
    private final By errorMessage = By.cssSelector("[data-test='error']");
    private final By completeHeader = By.className("complete-header");

    // Actions
    public void enterCheckoutInfo(String firstName, String lastName, String zipCode) {
        driver.findElement(firstNameField).sendKeys(firstName);
        driver.findElement(lastNameField).sendKeys(lastName);
        driver.findElement(zipCodeField).sendKeys(zipCode);
        ScreenShot.TakeScreenShot(driver, "EnterCheckoutInfo");
    }

    public void continueToOverview() {
        driver.findElement(continueButton).click();
        ScreenShot.TakeScreenShot(driver, "ContinueToOverview");
    }

    public void finishCheckout() {
        driver.findElement(finishButton).click();
        ScreenShot.TakeScreenShot(driver, "FinishCheckout");
    }

    public void cancelCheckout() {
        driver.findElement(cancelButton).click();
    }

    // Assertions
    public void verifyErrorMessage(String expectedMessage) {
        Assert.assertTrue(driver.findElement(errorMessage).isDisplayed());
        Assert.assertTrue(driver.findElement(errorMessage).getText().contains(expectedMessage));
    }

    public void verifyOrderCompletion() {
        Assert.assertTrue(driver.findElement(completeHeader).isDisplayed());
        Assert.assertEquals(driver.findElement(completeHeader).getText(), "Thank you for your order!");
    }
}