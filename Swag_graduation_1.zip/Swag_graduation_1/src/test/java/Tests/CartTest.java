package Tests;

import Base.TestBase;
import Pages.CartPage;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CartTest extends TestBase {

    @BeforeMethod
    public void login() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void addSingleItemToCart() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        Assert.assertEquals(cartPage.getCartItemCount(), 1);
    }

    @Test
    public void addMultipleItemsToCart() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");
        productsPage.addToCart("Sauce Labs Bike Light");
        productsPage.addToCart("Sauce Labs Bolt T-Shirt");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        Assert.assertEquals(cartPage.getCartItemCount(), 3);
    }

    @Test
    public void removeItemFromCart() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");
        productsPage.addToCart("Sauce Labs Bike Light");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.removeItem(0);
        Assert.assertEquals(cartPage.getCartItemCount(), 1);
    }

    @Test
    public void verifyCartBadgeUpdate() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");
        productsPage.addToCart("Sauce Labs Bike Light");
        Assert.assertEquals(productsPage.getCartBadgeCount(), "2");
    }
}