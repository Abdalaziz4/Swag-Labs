package Tests;

import Base.TestBase;
import Pages.LoginPage;
import org.testng.annotations.Test;

public class LoginTest extends TestBase {

    @Test
    public void validLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
        loginPage.validateSuccessfulLogin();
    }

    @Test
    public void invalidLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("invalid_user", "invalid_pass");
        loginPage.validateErrorMessage("Username and password do not match any user in this service");
    }

    @Test
    public void lockedUserLogin() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("locked_out_user", "secret_sauce");
        loginPage.validateErrorMessage("Sorry, this user has been locked out");
    }
}