package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ProductsTest extends TestBase {

    @Test
    public void verifyProductCount() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");

        ProductsPage productsPage = new ProductsPage(driver);
        Assert.assertEquals(productsPage.getProductCount(), 6);
    }

    @Test
    public void verifySorting() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");

        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.sortBy("Price (low to high)");
        Assert.assertEquals(productsPage.getFirstProductPrice(), "$7.99");
    }
}