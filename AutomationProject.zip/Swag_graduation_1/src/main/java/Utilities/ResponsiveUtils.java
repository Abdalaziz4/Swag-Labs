package Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;

public class ResponsiveUtils {
    public static void setMobileView(WebDriver driver) {
        driver.manage().window().setSize(new Dimension(360, 640));
    }

    public static boolean verifyElementVisibility(WebDriver driver, By locator) {
        return driver.findElement(locator).isDisplayed();
    }
}