package Utilities;

public class PerformanceTimer {
    private long startTime;

    public void start() {
        startTime = System.currentTimeMillis();
    }

    public long getElapsedTime() {
        return System.currentTimeMillis() - startTime;
    }

    public static boolean verifyLoadTime(long actualTime, long maxAllowedTime) {
        return actualTime <= maxAllowedTime;
    }
}