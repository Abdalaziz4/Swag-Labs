package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Utilities.ScreenShot;

public class CartPage {
    WebDriver driver;

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By cartItems = By.className("cart_item");
    private final By cartBadge = By.className("shopping_cart_badge");
    private final By checkoutButton = By.id("checkout");
    private final By continueShoppingButton = By.id("continue-shopping");
    private final By removeButtons = By.cssSelector("button[class='btn btn_secondary btn_small cart_button']");

    // Actions
    public void openCart() {
        driver.findElement(By.className("shopping_cart_link")).click();
        ScreenShot.TakeScreenShot(driver, "OpenCart");
    }

    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }

    public void proceedToCheckout() {
        driver.findElement(checkoutButton).click();
        ScreenShot.TakeScreenShot(driver, "ProceedToCheckout");
    }

    public void continueShopping() {
        driver.findElement(continueShoppingButton).click();
        ScreenShot.TakeScreenShot(driver, "ContinueShopping");
    }

    public void removeItem(int index) {
        driver.findElements(removeButtons).get(index).click();
        ScreenShot.TakeScreenShot(driver, "RemoveItem_" + index);
    }

    // Assertions
    public void verifyCartItemsCount(int expectedCount) {
        Assert.assertEquals(getCartItemCount(), expectedCount);
        ScreenShot.TakeScreenShot(driver, "VerifyCartItemsCount");
    }

    public void verifyCartIsEmpty() {
        Assert.assertTrue(driver.findElements(cartItems).isEmpty());
        Assert.assertTrue(driver.findElement(continueShoppingButton).isDisplayed());
        ScreenShot.TakeScreenShot(driver, "VerifyEmptyCart");
    }

    public void verifyCartBadgeCount(String expectedCount) {
        Assert.assertEquals(driver.findElement(cartBadge).getText(), expectedCount);
        ScreenShot.TakeScreenShot(driver, "VerifyCartBadge");
    }
}