package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Utilities.ScreenShot;

public class LoginPage {
    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By userNameField = By.id("user-name");
    private final By passwordField = By.id("password");
    private final By loginButton = By.id("login-button");
    private final By errorMessage = By.cssSelector("[data-test='error']");

    // Actions
    public void navigate() {
        driver.get("https://www.saucedemo.com/");
        ScreenShot.TakeScreenShot(driver, "NavigateToLogin");
    }

    public void enterUserName(String username) {
        driver.findElement(userNameField).sendKeys(username);
        ScreenShot.TakeScreenShot(driver, "EnterUsername");
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
        ScreenShot.TakeScreenShot(driver, "EnterPassword");
    }

    public void clickLoginButton() {
        driver.findElement(loginButton).click();
        ScreenShot.TakeScreenShot(driver, "ClickLogin");
    }

    public void confirmLogin(String username, String password) {
        enterUserName(username);
        enterPassword(password);
        clickLoginButton();
    }

    // Assertions
    public void validateSuccessfulLogin() {
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/inventory.html");
        ScreenShot.TakeScreenShot(driver, "LoginSuccess");
    }

    public void validateErrorMessage(String expectedMessage) {
        Assert.assertTrue(driver.findElement(errorMessage).isDisplayed());
        Assert.assertTrue(driver.findElement(errorMessage).getText().contains(expectedMessage));
        ScreenShot.TakeScreenShot(driver, "LoginError");
    }
}