package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CheckoutOverviewPage {
    WebDriver driver;

    public CheckoutOverviewPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By itemTotal = By.className("summary_subtotal_label");
    private final By tax = By.className("summary_tax_label");
    private final By total = By.className("summary_total_label");
    private final By finishButton = By.id("finish");
    private final By completeHeader = By.className("complete-header");

    public void verifyOrderSummary(int itemCount) {
        String totalText = driver.findElement(itemTotal).getText();
        Assert.assertTrue(totalText.contains(String.valueOf(itemCount) + " items"));
    }

    public void completePurchase() {
        driver.findElement(finishButton).click();
        Assert.assertTrue(driver.findElement(completeHeader).isDisplayed());
    }

    public void verifyTotalCalculation() {
        double itemTotal = Double.parseDouble(driver.findElement(this.itemTotal).getText().replace("Item total: $", ""));
        double tax = Double.parseDouble(driver.findElement(this.tax).getText().replace("Tax: $", ""));
        double total = Double.parseDouble(driver.findElement(this.total).getText().replace("Total: $", ""));

        Assert.assertEquals(total, itemTotal + tax, 0.001);
    }
}