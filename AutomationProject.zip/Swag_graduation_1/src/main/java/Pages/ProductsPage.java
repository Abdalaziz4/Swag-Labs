package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import Utilities.ScreenShot;

import java.util.List;

public class ProductsPage {
    WebDriver driver;

    public ProductsPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By productItems = By.className("inventory_item");
    private final By productImages = By.className("inventory_item_img");
    private final By sortDropdown = By.className("product_sort_container");
    private final By firstProductName = By.xpath("(//div[@class='inventory_item_name'])[1]");
    private final By firstProductPrice = By.xpath("(//div[@class='inventory_item_price'])[1]");
    private final By cartBadge = By.className("shopping_cart_badge");

    // Actions
    public int getProductCount() {
        return driver.findElements(productItems).size();
    }

    public void sortBy(String option) {
        Select dropdown = new Select(driver.findElement(sortDropdown));
        dropdown.selectByVisibleText(option);
        ScreenShot.TakeScreenShot(driver, "SortBy_" + option.replace(" ", ""));
    }

    public String getFirstProductName() {
        return driver.findElement(firstProductName).getText();
    }

    public String getFirstProductPrice() {
        return driver.findElement(firstProductPrice).getText();
    }

    public void addToCart(String productName) {
        String xpath = "//div[text()='" + productName + "']/ancestor::div[@class='inventory_item']//button";
        driver.findElement(By.xpath(xpath)).click();
        ScreenShot.TakeScreenShot(driver, "AddToCart_" + productName.replace(" ", ""));
    }

    public String getCartBadgeCount() {
        return driver.findElement(cartBadge).getText();
    }

    // Assertions
    public void verifyImagesLoaded() {
        List<WebElement> images = driver.findElements(productImages);
        for (WebElement img : images) {
            Assert.assertTrue(img.isDisplayed());
            Assert.assertFalse(img.getAttribute("src").isEmpty());
        }
        ScreenShot.TakeScreenShot(driver, "VerifyImages");
    }
}