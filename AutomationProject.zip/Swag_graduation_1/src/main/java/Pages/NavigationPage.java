package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Utilities.ScreenShot;

public class NavigationPage {
    WebDriver driver;

    public NavigationPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By menuButton = By.id("react-burger-menu-btn");
    private final By logoutLink = By.id("logout_sidebar_link");
    private final By aboutLink = By.id("about_sidebar_link");
    private final By resetLink = By.id("reset_sidebar_link");

    // Actions
    public void openMenu() {
        driver.findElement(menuButton).click();
        ScreenShot.TakeScreenShot(driver, "OpenMenu");
    }

    public void clickLogout() {
        openMenu();
        driver.findElement(logoutLink).click();
        ScreenShot.TakeScreenShot(driver, "ClickLogout");
    }

    public void clickAbout() {
        openMenu();
        driver.findElement(aboutLink).click();
        ScreenShot.TakeScreenShot(driver, "ClickAbout");
    }

    public void clickReset() {
        openMenu();
        driver.findElement(resetLink).click();
        ScreenShot.TakeScreenShot(driver, "ClickReset");
    }

    // Assertions
    public void verifyLogout() {
        Assert.assertEquals(driver.getCurrentUrl(), "https://www.saucedemo.com/");
        ScreenShot.TakeScreenShot(driver, "VerifyLogout");
    }

    public void verifyAboutPage() {
        Assert.assertTrue(driver.getCurrentUrl().contains("saucelabs.com"));
        ScreenShot.TakeScreenShot(driver, "VerifyAboutPage");
    }

    public void verifyReset() {
        Assert.assertFalse(driver.findElements(By.className("shopping_cart_badge")).size() > 0);
        ScreenShot.TakeScreenShot(driver, "VerifyReset");
    }
}