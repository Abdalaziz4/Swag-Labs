package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MenuPage {
    WebDriver driver;

    public MenuPage(WebDriver driver) {
        this.driver = driver;
    }

    private final By menuButton = By.id("react-burger-menu-btn");
    private final By logoutLink = By.id("logout_sidebar_link");
    private final By aboutLink = By.id("about_sidebar_link");
    private final By resetLink = By.id("reset_sidebar_link");

    public void openMenu() {
        driver.findElement(menuButton).click();
    }

    public void logout() {
        openMenu();
        driver.findElement(logoutLink).click();
    }

    public void navigateToAbout() {
        openMenu();
        driver.findElement(aboutLink).click();
    }

    public void resetAppState() {
        openMenu();
        driver.findElement(resetLink).click();
    }
}