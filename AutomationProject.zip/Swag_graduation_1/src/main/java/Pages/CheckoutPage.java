package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import Utilities.ScreenShot;

public class CheckoutPage {
    WebDriver driver;

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Locators
    private final By firstNameField = By.id("first-name");
    private final By lastNameField = By.id("last-name");
    private final By zipCodeField = By.id("postal-code");
    private final By continueButton = By.id("continue");
    private final By finishButton = By.id("finish");
    private final By cancelButton = By.id("cancel");
    private final By errorMessage = By.cssSelector("[data-test='error']");
    private final By completeHeader = By.className("complete-header");
    private final By ponyImage = By.className("pony_express");
    private final By totalLabel = By.className("summary_total_label");

    // Actions
    public void enterCheckoutInfo(String firstName, String lastName, String zipCode) {
        driver.findElement(firstNameField).sendKeys(firstName);
        driver.findElement(lastNameField).sendKeys(lastName);
        driver.findElement(zipCodeField).sendKeys(zipCode);
        ScreenShot.TakeScreenShot(driver, "EnterCheckoutInfo");
    }

    public void continueToOverview() {
        driver.findElement(continueButton).click();
        ScreenShot.TakeScreenShot(driver, "ContinueToOverview");
    }

    public void finishCheckout() {
        driver.findElement(finishButton).click();
        ScreenShot.TakeScreenShot(driver, "FinishCheckout");
    }

    public void cancelCheckout() {
        driver.findElement(cancelButton).click();
        ScreenShot.TakeScreenShot(driver, "CancelCheckout");
    }

    // Assertions
    public void verifyErrorMessage(String expectedMessage) {
        Assert.assertTrue(driver.findElement(errorMessage).isDisplayed());
        Assert.assertTrue(driver.findElement(errorMessage).getText().contains(expectedMessage));
        ScreenShot.TakeScreenShot(driver, "VerifyErrorMessage");
    }

    public void verifyOrderCompletion() {
        Assert.assertTrue(driver.findElement(completeHeader).isDisplayed());
        Assert.assertEquals(driver.findElement(completeHeader).getText(), "Thank you for your order!");
        Assert.assertTrue(driver.findElement(ponyImage).isDisplayed());
        ScreenShot.TakeScreenShot(driver, "VerifyOrderCompletion");
    }

    public void verifyTotal(String expectedTotal) {
        String actualTotal = driver.findElement(totalLabel).getText();
        Assert.assertEquals(actualTotal, "Total: " + expectedTotal);
        ScreenShot.TakeScreenShot(driver, "VerifyTotal");
    }
}