package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class UITest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void verifyButtonStates() {
        ProductsPage productsPage = new ProductsPage(driver);
        WebElement addToCartButton = driver.findElement(By.xpath("(//button[contains(text(), 'Add to cart')])[1]"));
        Actions actions = new Actions(driver);
        actions.moveToElement(addToCartButton).perform();
        String hoverStyle = addToCartButton.getCssValue("background-color");
        Assert.assertFalse(hoverStyle.isEmpty());
        addToCartButton.click();
        String buttonText = addToCartButton.getText();
        Assert.assertEquals(buttonText, "Remove");
    }
}