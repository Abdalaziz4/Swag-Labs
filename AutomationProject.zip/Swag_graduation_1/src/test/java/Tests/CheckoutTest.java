package Tests;

import Base.TestBase;
import Pages.CartPage;
import Pages.CheckoutPage;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CheckoutTest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");

        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.proceedToCheckout();
    }

    @Test
    public void checkoutSingleItem() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("John", "Doe", "12345");
        checkoutPage.continueToOverview();
        checkoutPage.finishCheckout();
        checkoutPage.verifyOrderCompletion();
    }

    @Test
    public void checkoutMultipleItems() {
        // إضافة عناصر إضافية للتأكد من إجمالي السعر
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Fleece Jacket");
        productsPage.addToCart("Sauce Labs Bolt T-Shirt");
        productsPage.addToCart("Sauce Labs Onesie");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.proceedToCheckout();

        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("John", "Doe", "12345");
        checkoutPage.continueToOverview();
        checkoutPage.verifyTotal("$95.97"); // تأكدت من الإجمالي بناءً على الأسعار
        checkoutPage.finishCheckout();
        checkoutPage.verifyOrderCompletion();
    }

    @Test
    public void missingFirstName() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("", "Doe", "12345");
        checkoutPage.continueToOverview();
        checkoutPage.verifyErrorMessage("First Name is required");
    }

    @Test
    public void missingZipCode() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("John", "Doe", "");
        checkoutPage.continueToOverview();
        checkoutPage.verifyErrorMessage("Postal Code is required");
    }

    @Test
    public void orderCompletion() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("John", "Doe", "12345");
        checkoutPage.continueToOverview();
        checkoutPage.finishCheckout();
        checkoutPage.verifyOrderCompletion();
    }

    @Test
    public void alphabeticZipCode() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.enterCheckoutInfo("John", "Doe", "ABCDE");
        checkoutPage.continueToOverview();
        checkoutPage.verifyErrorMessage("Error: Postal Code must be numeric");
    }

    @Test
    public void cancelCheckout() {
        CheckoutPage checkoutPage = new CheckoutPage(driver);
        checkoutPage.cancelCheckout();
        Assert.assertTrue(driver.getCurrentUrl().contains("cart.html"));
    }
}