package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.NavigationPage;
import Pages.ProductsPage;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NavigationTest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void menuLogout() {
        NavigationPage navigationPage = new NavigationPage(driver);
        navigationPage.clickLogout();
        navigationPage.verifyLogout();
    }

    @Test
    public void aboutPage() {
        NavigationPage navigationPage = new NavigationPage(driver);
        navigationPage.clickAbout();
        navigationPage.verifyAboutPage();
    }

    @Test
    public void resetAppState() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");

        NavigationPage navigationPage = new NavigationPage(driver);
        navigationPage.clickReset();
        navigationPage.verifyReset();
    }
}