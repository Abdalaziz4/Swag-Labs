package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SortingTest extends TestBase {
    private ProductsPage productsPage;

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
        productsPage = new ProductsPage(driver);
    }

    @Test
    public void verifySortAZ() {
        productsPage.sortBy("Name (A to Z)");
        Assert.assertEquals(productsPage.getFirstProductName(), "Sauce Labs Backpack");
    }

    @Test
    public void verifySortHighToLow() {
        productsPage.sortBy("Price (high to low)");
        Assert.assertEquals(productsPage.getFirstProductPrice(), "$49.99");
    }
}