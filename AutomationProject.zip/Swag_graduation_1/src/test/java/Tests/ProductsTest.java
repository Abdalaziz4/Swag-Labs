package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ProductsTest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void verifyProductDisplay() {
        ProductsPage productsPage = new ProductsPage(driver);
        Assert.assertEquals(productsPage.getProductCount(), 6);
    }

    @Test
    public void verifyImageLoading() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.verifyImagesLoaded();
    }

    @Test
    public void sortAZ() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.sortBy("Name (A to Z)");
        Assert.assertEquals(productsPage.getFirstProductName(), "Sauce Labs Backpack");
    }

    @Test
    public void sortZA() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.sortBy("Name (Z to A)");
        Assert.assertEquals(productsPage.getFirstProductName(), "Test.allTheThings() T-Shirt (Red)");
    }

    @Test
    public void sortLowHighPrice() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.sortBy("Price (low to high)");
        Assert.assertEquals(productsPage.getFirstProductPrice(), "$7.99");
    }

    @Test
    public void sortHighLowPrice() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.sortBy("Price (high to low)");
        Assert.assertEquals(productsPage.getFirstProductPrice(), "$49.99");
    }

    @Test
    public void verifyProductCount() {
        ProductsPage productsPage = new ProductsPage(driver);
        Assert.assertEquals(productsPage.getProductCount(), 6);
    }
}