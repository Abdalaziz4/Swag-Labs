package Tests;

import Base.TestBase;
import Pages.CartPage;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CartTest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void addSingleItem() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.verifyCartItemsCount(1);
    }

    @Test
    public void addMultipleItems() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");
        productsPage.addToCart("Sauce Labs Bike Light");
        productsPage.addToCart("Sauce Labs Bolt T-Shirt");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.verifyCartItemsCount(3);
    }

    @Test
    public void removeItem() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.removeItem(0);
        cartPage.verifyCartItemsCount(0);
    }

    @Test
    public void verifyCartBadgeUpdate() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Bike Light");
        productsPage.addToCart("Sauce Labs Onesie");

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.verifyCartBadgeCount("2");
    }

    @Test
    public void verifyEmptyCart() {
        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.verifyCartIsEmpty();
    }

    @Test
    public void verifyCartPersistence() {
        ProductsPage productsPage = new ProductsPage(driver);
        productsPage.addToCart("Sauce Labs Backpack");
        productsPage.addToCart("Sauce Labs Bike Light");

        driver.navigate().refresh();

        CartPage cartPage = new CartPage(driver);
        cartPage.openCart();
        cartPage.verifyCartItemsCount(2);
    }
}