package Tests;

import Base.TestBase;
import Pages.LoginPage;
import Pages.ProductsPage;
import org.openqa.selenium.Dimension;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ResponsiveTest extends TestBase {

    @BeforeMethod
    public void setup() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
    }

    @Test
    public void mobileView() {
        driver.manage().window().setSize(new Dimension(360, 640));
        ProductsPage productsPage = new ProductsPage(driver);
        Assert.assertEquals(productsPage.getProductCount(), 6);
    }
}