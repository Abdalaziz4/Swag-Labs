package Tests;

import Base.TestBase;
import Pages.LoginPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class PerformanceTest extends TestBase {

    @Test
    public void pageLoadTime() {
        long startTime = System.currentTimeMillis();
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigate();
        loginPage.confirmLogin("standard_user", "secret_sauce");
        long endTime = System.currentTimeMillis();
        long loadTime = endTime - startTime;
        Assert.assertTrue(loadTime < 3000, "Page load time exceeded 3 seconds: " + loadTime + "ms");
    }
}