package Tests;

import Base.TestBase;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ErrorTest extends TestBase {

    @Test
    public void verify404Handling() {
        driver.get("https://www.saucedemo.com/invalid");
        String pageSource = driver.getPageSource();
        Assert.assertTrue(pageSource.contains("404") || pageSource.contains("Not Found"));
    }
}